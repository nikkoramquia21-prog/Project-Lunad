# Changelog

All notable changes to LUNAD. Versions follow [semver](https://semver.org).

## [0.1.0-base] – 2026-11-11

Base (vanilla) version. Frozen; never edited.

### Added
- Single-file clickable prototype (`app/index.html`) with Booker, Provider and LGU/PTO roles
- Module 1: Rider Haul booking & dispatch: pickup by map pin, location or landmark; LGU fare matrix; 3-minute offers with next-rider fallback; no-match alternatives; agency scheduled trips
- Module 2: Provider registration with required documents and expiry dates; LGU approve / reject / request info / suspend; expiry reminders and auto-suspend
- Module 3: Proof of payment via provider QR; 15-minute confirmation; escalation to support; cash fallback
- Module 6: One-day multi-leg Trip Builder with budget
- Module 8: Stylized Catanduanes Travel Mapper with category filters and day route
- Module 9: Offline outbox with server recheck on sync
- Module 10: Storm signals per municipality pause new bookings
- Feature 1: App / SMS / Messenger notifications (simulated) with keyword replies
- Feature 2: Two-way ratings and fare disputes with LGU review
- Feature 3: LGU/PTO dashboard with role-based tabs, fare matrix scheduling, analytics, CSV export and audit log
- Feature 4: Cancellation and no-show fees
- Feature 6: Trip sharing and press-and-hold SOS
- Concept and process flows document

### Known limits
- Sample data only; no backend; data stays in one browser
- Map is stylized; Street View opens Google Maps
- GPS live tracking not implemented
