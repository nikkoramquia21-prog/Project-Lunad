# Contributing to LUNAD

## The base version is frozen

- `v0.1.0-base` is the first vanilla version of the prototype.
- **Never** edit, delete, move or re-push this tag. Use it only to extract or compare.
- To start from it: `git checkout -b my-branch v0.1.0-base`. This makes a new branch; the tag itself stays as it was.

## Branches

| Branch | Purpose |
|---|---|
| `main` | Latest approved version. Changed only through pull requests. |
| `feature/<short-name>` | New feature, e.g. `feature/live-tracking` |
| `fix/<short-name>` | Bug fix, e.g. `fix/fare-rounding` |
| `docs/<short-name>` | Docs only |

## Making a change

```bash
git checkout main && git pull
git checkout -b feature/live-tracking
# edit app/index.html, test it in the browser
git add -A
git commit -m "feat: simulated live rider tracking with ETA"
git push -u origin feature/live-tracking
```

Then open a pull request into `main`. The other co-founder reviews and merges it.

### Commit messages

Start with a type: `feat:` new feature · `fix:` bug fix · `docs:` documentation · `style:` look only · `refactor:` code cleanup, same behavior · `chore:` repo housekeeping.

## Versioning (semver)

`MAJOR.MINOR.PATCH`

- **PATCH** (0.1.0 → 0.1.1): bug fixes, text changes
- **MINOR** (0.1.0 → 0.2.0): new features or modules
- **MAJOR** (0.x → 1.0.0): first real launch with a backend, or breaking changes

## Releasing a version

After merging into `main`:

1. Update `VERSION` and add a section to `CHANGELOG.md`.
2. Commit: `chore: release v0.2.0`
3. Tag and push:
   ```bash
   git tag -a v0.2.0 -m "v0.2.0 – live tracking"
   git push origin main --tags
   ```
4. On GitHub: Releases → Draft a new release → choose the tag → attach the demo video if there is one.

Released tags are never moved or deleted. A mistake gets fixed in the next version.
