# One-time setup (do this once)

## 1. Push the base version

You need Git installed and push access to `nikkoramquia21-prog/Project-Lunad` (Nikko owns it; he can add you under Settings → Collaborators).

```bash
cd Project-Lunad
bash push-base.sh
```

This commits everything to `main`, tags it **`v0.1.0-base`** and pushes both. If GitHub asks you to sign in, use your GitHub username and a personal access token, or sign in with `gh auth login` first.

## 2. Lock the base version (Nikko, as repo owner)

A Git tag can still be deleted or moved by anyone with push access unless the repo blocks it. Turn on these two rules:

**Protect the base tag**
1. Repo → Settings → Rules → Rulesets → New ruleset → **New tag ruleset**
2. Name: `freeze-base` · Enforcement: **Active**
3. Target tags → Add target → Include by pattern: `v*`
4. Turn on **Restrict updates** and **Restrict deletions** (leave creations allowed so new versions can be tagged).
5. Leave the bypass list empty, then Save.

**Protect `main`**
1. Rulesets → New ruleset → **New branch ruleset**
2. Name: `protect-main` · Enforcement: **Active** · Target: default branch
3. Turn on **Require a pull request before merging** (1 approval) and **Block force pushes**. Save.

## 3. Publish the base release

Releases → Draft a new release → choose tag `v0.1.0-base` → title `v0.1.0-base – Vanilla prototype` → attach `LUNAD_Booker_Demo_Tagalog.mp4` → Publish.

GitHub adds a downloadable zip of the frozen code to the release automatically. That zip is the "extract-only" copy.

## 4. From now on

Follow [CONTRIBUTING.md](CONTRIBUTING.md): branch → pull request → merge → bump `VERSION` → new tag.
