# Changelog

All notable changes to LUNAD. Versions follow [semver](https://semver.org).

## [0.2.0] – 2026-11-12

Scoped the prototype to the IGNITE Catanduanes MVP and switched to the LUNAD brand palette.

### Changed
- Brand colors: swapped the teal/coral/orange palette for the logo's blue (#0EA5E9) and gold (#FACC15) throughout the UI, map pins and markers
- Vehicle types trimmed to the MVP's two booking options: TODA route (tricycle) and Direct booking (car, van)
- "Ride" screen now flags that TODA tricycles currently run the Virac–San Andres corridor only, and suggests Direct booking outside it
- Map renamed "Tourism map"; "Concept & roadmap" panel rewritten to match the MVP scope and the doc's open questions

### Removed
- Habal-habal (motorcycle), 360 ride and travel-agency scheduled-trip vehicle types and their sample providers — motorcycles are excluded from the MVP pending LTFRB/provincial approval; 360 ride and scheduled agency trips aren't in MVP scope
- Day Trip / Trip Builder tab and the map's day-route overlay — multi-day/multi-leg trip planning is a Roadmap item, not MVP

### Known limits (unchanged from v0.1.0-base)
- Sample data only; no backend; data stays in one browser
- Map is stylized; Street View opens Google Maps
- GPS live tracking and reviews-on-map-pins are not implemented

## [0.1.0-base] – 2026-11-11

Base (vanilla) version. Frozen; never edited.

### Added
- Single-file clickable prototype (`app/index.html`) with Booker, Provider and LGU/PTO roles
- Module 1: Rider Haul booking & dispatch: pickup by map pin, location or landmark; LGU fare matrix; 3-minute offers with next-rider fallback; no-match alternatives; agency scheduled trips
- Module 2: Provider registration with required documents and expiry dates; LGU approve / reject / request info / suspend; expiry reminders and auto-suspend
- Module 3: Proof of payment via provider QR; 15-minute confirmation; escalation to support; cash fallback
- Module 6: One-day multi-leg Trip Builder with budget
- Module 8: Stylized Catanduanes Travel Mapper with category filters and day route
- Module 9: Offline outbox with server recheck on sync
- Module 10: Storm signals per municipality pause new bookings
- Feature 1: App / SMS / Messenger notifications (simulated) with keyword replies
- Feature 2: Two-way ratings and fare disputes with LGU review
- Feature 3: LGU/PTO dashboard with role-based tabs, fare matrix scheduling, analytics, CSV export and audit log
- Feature 4: Cancellation and no-show fees
- Feature 6: Trip sharing and press-and-hold SOS
- Concept and process flows document

### Known limits
- Sample data only; no backend; data stays in one browser
- Map is stylized; Street View opens Google Maps
- GPS live tracking not implemented
