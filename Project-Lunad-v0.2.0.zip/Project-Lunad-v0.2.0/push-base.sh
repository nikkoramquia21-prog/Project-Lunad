#!/usr/bin/env bash
# One-time setup: pushes LUNAD v0.1.0-base to GitHub and tags it.
# Run from inside this folder:  bash push-base.sh
set -euo pipefail
REPO="${REPO:-https://github.com/nikkoramquia21-prog/Project-Lunad.git}"
TAG="v0.1.0-base"

git config user.name >/dev/null || { echo "Set your name first: git config --global user.name \"Your Name\""; exit 1; }
git config user.email >/dev/null || { echo "Set your email first: git config --global user.email you@example.com"; exit 1; }

[ -d .git ] || git init -q
git checkout -q -B main

if git rev-parse -q --verify "refs/tags/$TAG" >/dev/null || git ls-remote --exit-code --tags origin "$TAG" >/dev/null 2>&1; then
  echo "Tag $TAG already exists. The base version is frozen, so nothing was re-tagged."; exit 1
fi

# Bring in anything already on GitHub (e.g. a README made when the repo was created)
git remote get-url origin >/dev/null 2>&1 || git remote add origin "$REPO"
if git ls-remote --exit-code --heads origin main >/dev/null 2>&1; then
  git fetch -q origin main
  git reset -q origin/main   # keep our files and anything already on GitHub
fi

git add --ignore-removal -- . ':!push-base.sh'
git commit -q -m "feat: LUNAD base version v0.1.0 (vanilla prototype)

Single-file clickable prototype for IGNITE Catanduanes 2026:
Rider Haul dispatch, LGU verification, proof of payment, day-trip
builder, travel mapper, offline sync, storm signals, notifications,
ratings and disputes, LGU/PTO dashboard, cancellation rules, SOS.

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_018SZpux8nrsudvknLa7Y8Zj"

git tag -a "$TAG" -m "LUNAD base (vanilla) version. Frozen: do not edit, move or delete."
git push -u origin main
git push origin "$TAG"
echo
echo "Done. Base version pushed and tagged $TAG."
echo "Next: on GitHub, make a Release from $TAG and turn on the tag ruleset (see SETUP.md)."
