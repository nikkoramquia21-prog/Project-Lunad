# Project LUNAD

The ride hub of Catanduanes. Bookers see which LGU-verified riders are online, book a Direct ride (car/van) or a TODA route (tricycle), and pay the driver directly. Entry for the IGNITE Catanduanes Startup Bootcamp & Hackathon (Nov 24–26, 2026).

> **Status:** clickable prototype with sample data. No backend yet. Data is saved only in the browser that opens it.

## Run it

No install, no build step. It is a single HTML file.

| Option | How |
|---|---|
| Local | Download or clone the repo, then open `app/index.html` in Chrome. |
| GitHub Pages | Settings → Pages → Deploy from branch → `main` / root. Open `https://<owner>.github.io/Project-Lunad/app/`. |
| Claude artifact | In Claude, attach `app/index.html` and ask it to publish the page as an artifact. Each person publishes their own copy. |

Use the dropdown at the top to switch roles: **Booker**, **Provider**, **LGU / PTO**. Use **Reset demo data** in the side panel to start over.

## What is in the prototype

- Direct booking (car or van, any town) and TODA route booking (tricycle, Virac–San Andres corridor)
- Rider Haul dispatch (3-minute offers, next-rider fallback, alternatives)
- Provider registration & LGU verification (documents, expiry, auto-suspend)
- Proof of payment (QR, 15-minute confirm, escalation, cash fallback)
- Tourism map with offline downloads, offline outbox & sync, weather & safety
- SMS / Messenger notifications (simulated), ratings & fare disputes, LGU/PTO dashboard, cancellation & no-show rules, trip sharing & SOS

Motorcycle riders, reviews on map pins, destination pages, the multi-day Trip Builder, Stays and the online payment gateway are Roadmap/Later items — see `docs/LUNAD-concept-and-process-flows.txt`.

Full spec: [`docs/LUNAD-concept-and-process-flows.txt`](docs/LUNAD-concept-and-process-flows.txt)

## Repo layout

```
app/index.html     the prototype (HTML, CSS and JS in one file)
docs/              concept and process flows
VERSION            current version (semver)
CHANGELOG.md       what changed in each version
CONTRIBUTING.md    branching, versioning and release rules
```

## Versions

`v0.1.0-base` is the **base (vanilla) version** and is never changed. Every later change goes through a branch, a pull request and a new version tag. See [CONTRIBUTING.md](CONTRIBUTING.md).

To get the untouched base version at any time:

```bash
git clone https://github.com/nikkoramquia21-prog/Project-Lunad.git
cd Project-Lunad
git checkout v0.1.0-base        # read-only snapshot
```

Or download the zip from the **v0.1.0-base** release on GitHub.
